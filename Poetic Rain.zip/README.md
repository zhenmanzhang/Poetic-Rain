# matrix
Matrix like animation using HTML5 Canvas. Inspired from [sample code](http://thecodeplayer.com/walkthrough/matrix-rain-animation-html5-canvas-javascript) on [thecodeplayer.com](http://thecodeplayer.com/).

See it in action @ http://parambirs.github.io/matrix

@ 2020-09-05 - added lively customizable options (rainbow / color select) - khuong

---

## 古诗词字符雨（本地定制版）

在原版日文假名矩阵雨的基础上，把下落字符换成中国古典诗词名句（李白 / 杜甫 / 苏轼为主，兼收历代名篇），并扩展了 Lively「自定义」面板开关。

**自定义面板选项**

| 选项 | 说明 |
| --- | --- |
| 文字内容 | 古诗词·整句竖排 / 古诗词·随机单字 / 日文假名（原版） |
| 诗人 / 主题 | 全部名句、16 个诗人或主题分组、自动轮播 |
| 轮播间隔（秒） | 选「自动轮播」时每组停留时间，5–120 秒 |
| 字号 | 8–48px，越大字符越少越醒目 |
| 字体 | 楷体 / 宋体 / 微软雅黑 / 隶书 / 幼圆 |
| 高清渲染 | 按屏幕缩放比放大缓冲区，高分屏笔画更锐利（更耗性能时可关） |
| 字体颜色 | 单色模式下的字符颜色 |
| 彩虹模式 | 开启后字符颜色随时间流转 |
| 彩虹速度 | 0–100，指数刻度；按真实时间推进，与下落速度无关 |
| 彩虹渐变跨度 | 0–100，控制横向彩色条纹的疏密 |
| 下落速度 | 0–100，指数刻度；越大越快 |
| 拖尾长度 | 0–100；越大拖尾越长 |
| 发光强度 | 0–24px 字符辉光 |
| 高亮字头 | 最新落下的字提亮偏白 |

所有滑块均采用指数（感知型）刻度，低值细腻微调、高值变化剧烈，避免「调了看不出区别」。