var root = {
  wavecolor: { r: 0, g: 255, b: 70 },
  rainbow: false,
  rainbowHz: 0.35,      // 每秒色相循环圈数（面板 0–100 指数映射）
  rainbowSpread: 0.12,  // 列间色相偏移：0 = 全屏同色，越大横向条纹越密
  matrixspeed: 50,      // 下落帧间隔 ms，越小越快
  charMode: 0,          // 0 = 古诗词·整句竖排  1 = 古诗词·随机单字  2 = 日文假名（原版）
  poetGroup: 0,         // 0 = 全部名句；1..N = 第 N 个分组；N+1 = 自动轮播
  autoRotate: false,    // 自动轮播开关（由 poetGroup 派生）
  trailAlpha: 0.055,    // 拖尾透明度，越小拖尾越长
  glow: 0,              // 字符发光强度（shadowBlur 像素），0 = 关闭
  brightHead: true,     // 高亮字头：最新落下的字提亮偏白
  fontKey: 0,           // 字体预设索引
  hidpi: true           // 高清渲染：按屏幕缩放比放大缓冲区，笔画更锐利
};

// 字体预设：中文诗词优先书法感字体，缺字自动回退到系统字体
var fontPresets = [
  '"KaiTi", "楷体", "STKaiti", "Microsoft YaHei", sans-serif',
  '"SimSun", "宋体", "NSimSun", "Microsoft YaHei", serif',
  '"Microsoft YaHei", "微软雅黑", "PingFang SC", sans-serif',
  '"LiSu", "隶书", "KaiTi", "楷体", "Microsoft YaHei", serif',
  '"YouYuan", "幼圆", "Microsoft YaHei", sans-serif'
];
var fontStack = fontPresets[0];

var c = document.getElementById("c");
var ctx = c.getContext("2d");

// making the canvas full screen
// 高分屏适配：开启“高清渲染”时，后备缓冲区按设备像素比放大、坐标系等比缩放，
// 在 125% / 150% / 200% 缩放的屏幕上笔画边缘依然锐利；关闭则回到 1:1 像素，更省性能。
// viewW / viewH 为逻辑尺寸，脚本内所有布局计算统一使用它们。
var viewW = window.innerWidth;
var viewH = window.innerHeight;

function setupCanvas() {
  var dpr = root.hidpi ? Math.max(1, window.devicePixelRatio || 1) : 1;
  c.width = Math.round(viewW * dpr);
  c.height = Math.round(viewH * dpr);
  c.style.width = viewW + "px";
  c.style.height = viewH + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
setupCanvas();

// ---------------------------------------------------------------------------
// 中国古典诗词千古名句（李白 / 杜甫 / 苏轼 为主，兼收历代名篇）
// 每句去掉标点，便于自上而下逐字竖排显示
// ---------------------------------------------------------------------------
var poemGroups = [
  { name: "李白", lines: [
  "床前明月光疑是地上霜",
  "举头望明月低头思故乡",
  "君不见黄河之水天上来",
  "奔流到海不复回",
  "天生我材必有用",
  "千金散尽还复来",
  "人生得意须尽欢莫使金樽空对月",
  "呼儿将出换美酒与尔同销万古愁",
  "长风破浪会有时直挂云帆济沧海",
  "两岸猿声啼不住轻舟已过万重山",
  "孤帆远影碧空尽唯见长江天际流",
  "举杯邀明月对影成三人",
  "抽刀断水水更流举杯消愁愁更愁",
  "仰天大笑出门去我辈岂是蓬蒿人",
  "安能摧眉折腰事权贵使我不得开心颜",
  "飞流直下三千尺疑是银河落九天",
  "桃花潭水深千尺不及汪伦送我情",
  "众鸟高飞尽孤云独去闲",
  "相看两不厌只有敬亭山",
  "俱怀逸兴壮思飞欲上青天揽明月",
  "长风万里送秋雁对此可以酣高楼",
  "人生在世不称意明朝散发弄扁舟",
  "弃我去者昨日之日不可留",
  "乱我心者今日之日多烦忧",
  "我寄愁心与明月随君直到夜郎西",
  "杨花落尽子规啼闻道龙标过五溪",
  "云想衣裳花想容春风拂槛露华浓",
  "峨眉山月半轮秋影入平羌江水流",
  "青山横北郭白水绕东城",
  "浮云游子意落日故人情",
  "山随平野尽江入大荒流",
  "月下飞天镜云生结海楼",
  "仍怜故乡水万里送行舟",
  "小时不识月呼作白玉盘",
  "两人对酌山花开一杯一杯复一杯",
  "且就洞庭赊月色将船买酒白云边",
  "三山半落青天外二水中分白鹭洲",
  "总为浮云能蔽日长安不见使人愁",
  "平林漠漠烟如织寒山一带伤心碧",
  "何处是归程长亭更短亭",
  "请君试问东流水别意与之谁短长",
  "燕山雪花大如席片片吹落轩辕台",
  "五岳寻仙不辞远一生好入名山游"
  ] },
  { name: "杜甫", lines: [
  "会当凌绝顶一览众山小",
  "岱宗夫如何齐鲁青未了",
  "造化钟神秀阴阳割昏晓",
  "荡胸生层云决眦入归鸟",
  "国破山河在城春草木深",
  "感时花溅泪恨别鸟惊心",
  "烽火连三月家书抵万金",
  "白头搔更短浑欲不胜簪",
  "无边落木萧萧下不尽长江滚滚来",
  "万里悲秋常作客百年多病独登台",
  "风急天高猿啸哀渚清沙白鸟飞回",
  "艰难苦恨繁霜鬓潦倒新停浊酒杯",
  "两个黄鹂鸣翠柳一行白鹭上青天",
  "窗含西岭千秋雪门泊东吴万里船",
  "好雨知时节当春乃发生",
  "随风潜入夜润物细无声",
  "野径云俱黑江船火独明",
  "晓看红湿处花重锦官城",
  "正是江南好风景落花时节又逢君",
  "出师未捷身先死长使英雄泪满襟",
  "映阶碧草自春色隔叶黄鹂空好音",
  "三顾频烦天下计两朝开济老臣心",
  "露从今夜白月是故乡明",
  "星垂平野阔月涌大江流",
  "名岂文章著官应老病休",
  "飘飘何所似天地一沙鸥",
  "安得广厦千万间大庇天下寒士俱欢颜",
  "朱门酒肉臭路有冻死骨",
  "读书破万卷下笔如有神",
  "为人性僻耽佳句语不惊人死不休",
  "尔曹身与名俱灭不废江河万古流",
  "白日放歌须纵酒青春作伴好还乡",
  "却看妻子愁何在漫卷诗书喜欲狂",
  "即从巴峡穿巫峡便下襄阳向洛阳",
  "迟日江山丽春风花草香",
  "泥融飞燕子沙暖睡鸳鸯",
  "江碧鸟逾白山青花欲燃",
  "黄四娘家花满蹊千朵万朵压枝低",
  "留连戏蝶时时舞自在娇莺恰恰啼",
  "花径不曾缘客扫蓬门今始为君开",
  "锦江春色来天地玉垒浮云变古今",
  "清江一曲抱村流长夏江村事事幽",
  "自去自来梁上燕相亲相近水中鸥",
  "老妻画纸为棋局稚子敲针作钓钩",
  "舍南舍北皆春水但见群鸥日日来",
  "丛菊两开他日泪孤舟一系故园心",
  "五更鼓角声悲壮三峡星河影动摇",
  "落日照大旗马鸣风萧萧",
  "白也诗无敌飘然思不群",
  "丹青不知老将至富贵于我如浮云",
  "绝代有佳人幽居在空谷",
  "天寒翠袖薄日暮倚修竹",
  "致君尧舜上再使风俗淳",
  "八月秋高风怒号卷我屋上三重茅",
  "床头屋漏无干处雨脚如麻未断绝",
  "新松恨不高千尺恶竹应须斩万竿"
  ] },
  { name: "苏轼", lines: [
  "大江东去浪淘尽千古风流人物",
  "乱石穿空惊涛拍岸卷起千堆雪",
  "江山如画一时多少豪杰",
  "人生如梦一尊还酹江月",
  "明月几时有把酒问青天",
  "不知天上宫阙今夕是何年",
  "我欲乘风归去又恐琼楼玉宇高处不胜寒",
  "起舞弄清影何似在人间",
  "转朱阁低绮户照无眠",
  "不应有恨何事长向别时圆",
  "人有悲欢离合月有阴晴圆缺此事古难全",
  "但愿人长久千里共婵娟",
  "不识庐山真面目只缘身在此山中",
  "横看成岭侧成峰远近高低各不同",
  "莫听穿林打叶声何妨吟啸且徐行",
  "竹杖芒鞋轻胜马谁怕一蓑烟雨任平生",
  "料峭春风吹酒醒微冷山头斜照却相迎",
  "回首向来萧瑟处归去也无风雨也无晴",
  "十年生死两茫茫不思量自难忘",
  "千里孤坟无处话凄凉",
  "纵使相逢应不识尘满面鬓如霜",
  "夜来幽梦忽还乡小轩窗正梳妆",
  "相顾无言惟有泪千行",
  "料得年年肠断处明月夜短松冈",
  "花褪残红青杏小燕子飞时绿水人家绕",
  "枝上柳绵吹又少天涯何处无芳草",
  "墙里秋千墙外道墙外行人墙里佳人笑",
  "笑渐不闻声渐悄多情却被无情恼",
  "缺月挂疏桐漏断人初静",
  "谁见幽人独往来缥缈孤鸿影",
  "惊起却回头有恨无人省",
  "拣尽寒枝不肯栖寂寞沙洲冷",
  "人生到处知何似应似飞鸿踏雪泥",
  "水光潋滟晴方好山色空蒙雨亦奇",
  "欲把西湖比西子淡妆浓抹总相宜",
  "春宵一刻值千金花有清香月有阴",
  "粗缯大布裹生涯腹有诗书气自华",
  "休对故人思故国且将新火试新茶诗酒趁年华",
  "夜饮东坡醒复醉归来仿佛三更",
  "家童鼻息已雷鸣敲门都不应倚杖听江声",
  "长恨此身非我有何时忘却营营",
  "小舟从此逝江海寄余生",
  "荷尽已无擎雨盖菊残犹有傲霜枝",
  "一年好景君须记最是橙黄橘绿时",
  "老夫聊发少年狂左牵黄右擎苍",
  "酒酣胸胆尚开张鬓微霜又何妨",
  "持节云中何日遣冯唐",
  "会挽雕弓如满月西北望射天狼",
  "一别都门三改火天涯踏尽红尘",
  "依然一笑作春温无波真古井有节是秋筠",
  "人生如逆旅我亦是行人",
  "山下兰芽短浸溪松间沙路净无泥",
  "谁道人生无再少门前流水尚能西",
  "休将白发唱黄鸡",
  "细雨斜风作晓寒淡烟疏柳媚晴滩",
  "人间有味是清欢",
  "若言琴上有琴声放在匣中何不鸣",
  "梨花淡白柳深青柳絮飞时花满城",
  "惆怅东栏一株雪人生看得几清明",
  "一点浩然气千里快哉风",
  "万事到头都是梦休休明日黄花蝶也愁",
  "欲寄相思千点泪流不到楚江东"
  ] },
  { name: "王维", lines: [
  "独在异乡为异客每逢佳节倍思亲",
  "遥知兄弟登高处遍插茱萸少一人",
  "大漠孤烟直长河落日圆",
  "明月松间照清泉石上流",
  "空山新雨后天气晚来秋",
  "行到水穷处坐看云起时",
  "劝君更尽一杯酒西出阳关无故人",
  "返景入深林复照青苔上",
  "深林人不知明月来相照",
  "人闲桂花落夜静春山空",
  "月出惊山鸟时鸣春涧中",
  "江流天地外山色有无中"
  ] },
  { name: "白居易", lines: [
  "野火烧不尽春风吹又生",
  "在天愿作比翼鸟在地愿为连理枝",
  "天长地久有时尽此恨绵绵无绝期",
  "同是天涯沦落人相逢何必曾相识",
  "回眸一笑百媚生六宫粉黛无颜色",
  "晚来天欲雪能饮一杯无",
  "绿蚁新醅酒红泥小火炉",
  "几处早莺争暖树谁家新燕啄春泥",
  "乱花渐欲迷人眼浅草才能没马蹄",
  "可怜九月初三夜露似真珠月似弓",
  "人间四月芳菲尽山寺桃花始盛开"
  ] },
  { name: "边塞 · 山水", lines: [
  "白日依山尽黄河入海流",
  "欲穷千里目更上一层楼",
  "黄河远上白云间一片孤城万仞山",
  "羌笛何须怨杨柳春风不度玉门关",
  "醉卧沙场君莫笑古来征战几人回",
  "秦时明月汉时关万里长征人未还",
  "但使龙城飞将在不教胡马度阴山",
  "黄沙百战穿金甲不破楼兰终不还",
  "洛阳亲友如相问一片冰心在玉壶",
  "忽如一夜春风来千树万树梨花开",
  "山回路转不见君雪上空留马行处",
  "莫愁前路无知己天下谁人不识君",
  "战士军前半死生美人帐下犹歌舞",
  "春眠不觉晓处处闻啼鸟",
  "夜来风雨声花落知多少",
  "气蒸云梦泽波撼岳阳城",
  "野旷天低树江清月近人",
  "千山鸟飞绝万径人踪灭",
  "孤舟蓑笠翁独钓寒江雪",
  "月落乌啼霜满天江枫渔火对愁眠",
  "姑苏城外寒山寺夜半钟声到客船",
  "日暮乡关何处是烟波江上使人愁",
  "晴川历历汉阳树芳草萋萋鹦鹉洲",
  "春潮带雨晚来急野渡无人舟自横",
  "独怜幽草涧边生上有黄鹂深树鸣",
  "去年花里逢君别今日花开又一年",
  "鸡声茅店月人迹板桥霜",
  "过尽千帆皆不是斜晖脉脉水悠悠",
  "曲径通幽处禅房花木深",
  "清晨入古寺初日照高林",
  "山光悦鸟性潭影空人心",
  "万籁此都寂但余钟磬音",
  "鸟宿池边树僧敲月下门",
  "只在此山中云深不知处",
  "去年今日此门中人面桃花相映红",
  "人面不知何处去桃花依旧笑春风",
  "蝉噪林逾静鸟鸣山更幽",
  "居高声自远非是藉秋风",
  "海日生残夜江春入旧年",
  "潮平两岸阔风正一帆悬",
  "白毛浮绿水红掌拨清波",
  "谁知盘中餐粒粒皆辛苦"
  ] },
  { name: "李商隐 · 杜牧", lines: [
  "春蚕到死丝方尽蜡炬成灰泪始干",
  "相见时难别亦难东风无力百花残",
  "身无彩凤双飞翼心有灵犀一点通",
  "昨夜星辰昨夜风画楼西畔桂堂东",
  "锦瑟无端五十弦一弦一柱思华年",
  "庄生晓梦迷蝴蝶望帝春心托杜鹃",
  "沧海月明珠有泪蓝田日暖玉生烟",
  "此情可待成追忆只是当时已惘然",
  "夕阳无限好只是近黄昏",
  "何当共剪西窗烛却话巴山夜雨时",
  "君问归期未有期巴山夜雨涨秋池",
  "天意怜幽草人间重晚晴",
  "嫦娥应悔偷灵药碧海青天夜夜心",
  "春心莫共花争发一寸相思一寸灰",
  "秋阴不散霜飞晚留得枯荷听雨声",
  "停车坐爱枫林晚霜叶红于二月花",
  "远上寒山石径斜白云生处有人家",
  "商女不知亡国恨隔江犹唱后庭花",
  "烟笼寒水月笼沙夜泊秦淮近酒家",
  "东风不与周郎便铜雀春深锁二乔",
  "清明时节雨纷纷路上行人欲断魂",
  "借问酒家何处有牧童遥指杏花村",
  "千里莺啼绿映红水村山郭酒旗风",
  "南朝四百八十寺多少楼台烟雨中",
  "二十四桥明月夜玉人何处教吹箫",
  "青山隐隐水迢迢秋尽江南草未凋",
  "银烛秋光冷画屏轻罗小扇扑流萤",
  "天阶夜色凉如水卧看牵牛织女星",
  "十年一觉扬州梦赢得青楼薄幸名"
  ] },
  { name: "韩愈 · 刘禹锡 · 李贺 · 孟郊", lines: [
  "天街小雨润如酥草色遥看近却无",
  "云横秦岭家何在雪拥蓝关马不前",
  "业精于勤荒于嬉行成于思毁于随",
  "李杜文章在光焰万丈长",
  "沉舟侧畔千帆过病树前头万木春",
  "山不在高有仙则名水不在深有龙则灵",
  "斯是陋室惟吾德馨",
  "旧时王谢堂前燕飞入寻常百姓家",
  "东边日出西边雨道是无晴却有晴",
  "自古逢秋悲寂寥我言秋日胜春朝",
  "晴空一鹤排云上便引诗情到碧霄",
  "千淘万漉虽辛苦吹尽狂沙始到金",
  "莫道桑榆晚为霞尚满天",
  "黑云压城城欲摧甲光向日金鳞开",
  "天若有情天亦老",
  "大漠沙如雪燕山月似钩",
  "春风得意马蹄疾一日看尽长安花",
  "谁言寸草心报得三春晖",
  "不知细叶谁裁出二月春风似剪刀",
  "少小离家老大回乡音无改鬓毛衰",
  "儿童相见不相识笑问客从何处来"
  ] },
  { name: "陶渊明 · 曹操 · 屈原", lines: [
  "采菊东篱下悠然见南山",
  "山气日夕佳飞鸟相与还",
  "问君何能尔心远地自偏",
  "结庐在人境而无车马喧",
  "羁鸟恋旧林池鱼思故渊",
  "久在樊笼里复得返自然",
  "衣沾不足惜但使愿无违",
  "奇文共欣赏疑义相与析",
  "盛年不重来一日难再晨",
  "及时当勉励岁月不待人",
  "对酒当歌人生几何",
  "譬如朝露去日苦多",
  "何以解忧唯有杜康",
  "青青子衿悠悠我心",
  "山不厌高海不厌深",
  "周公吐哺天下归心",
  "东临碣石以观沧海",
  "水何澹澹山岛竦峙",
  "秋风萧瑟洪波涌起",
  "日月之行若出其中",
  "星汉灿烂若出其里",
  "老骥伏枥志在千里",
  "烈士暮年壮心不已",
  "路漫漫其修远兮吾将上下而求索",
  "长太息以掩涕兮哀民生之多艰",
  "亦余心之所善兮虽九死其犹未悔"
  ] },
  { name: "李煜 · 王勃", lines: [
  "春花秋月何时了往事知多少",
  "问君能有几多愁恰似一江春水向东流",
  "雕栏玉砌应犹在只是朱颜改",
  "无言独上西楼月如钩寂寞梧桐深院锁清秋",
  "剪不断理还乱是离愁别是一般滋味在心头",
  "林花谢了春红太匆匆",
  "自是人生长恨水长东",
  "流水落花春去也天上人间",
  "海内存知己天涯若比邻",
  "落霞与孤鹜齐飞秋水共长天一色",
  "老当益壮宁移白首之心",
  "穷且益坚不坠青云之志"
  ] },
  { name: "宋词", lines: [
  "昨夜西风凋碧树独上高楼望尽天涯路",
  "无可奈何花落去似曾相识燕归来",
  "不如怜取眼前人",
  "衣带渐宽终不悔为伊消得人憔悴",
  "多情自古伤离别更那堪冷落清秋节",
  "今宵酒醒何处杨柳岸晓风残月",
  "执手相看泪眼竟无语凝噎",
  "便纵有千种风情更与何人说",
  "两情若是久长时又岂在朝朝暮暮",
  "金风玉露一相逢便胜却人间无数",
  "柔情似水佳期如梦忍顾鹊桥归路",
  "自在飞花轻似梦无边丝雨细如愁",
  "可堪孤馆闭春寒杜鹃声里斜阳暮",
  "泪眼问花花不语乱红飞过秋千去",
  "人生自是有情痴此恨不关风与月",
  "醉翁之意不在酒在乎山水之间也",
  "落花人独立微雨燕双飞",
  "叶上初阳干宿雨水面清圆一一风荷举",
  "一川烟草满城风絮梅子黄时雨",
  "二十四桥仍在波心荡冷月无声",
  "念桥边红药年年知为谁生"
  ] },
  { name: "辛弃疾 · 李清照 · 陆游", lines: [
  "众里寻他千百度蓦然回首那人却在灯火阑珊处",
  "醉里挑灯看剑梦回吹角连营",
  "了却君王天下事赢得生前身后名",
  "青山遮不住毕竟东流去",
  "明月别枝惊鹊清风半夜鸣蝉",
  "稻花香里说丰年听取蛙声一片",
  "千古兴亡多少事悠悠不尽长江滚滚流",
  "我见青山多妩媚料青山见我应如是",
  "少年不识愁滋味爱上层楼",
  "生当作人杰死亦为鬼雄",
  "至今思项羽不肯过江东",
  "莫道不销魂帘卷西风人比黄花瘦",
  "知否知否应是绿肥红瘦",
  "云中谁寄锦书来雁字回时月满西楼",
  "花自飘零水自流一种相思两处闲愁",
  "此情无计可消除才下眉头却上心头",
  "山重水复疑无路柳暗花明又一村",
  "王师北定中原日家祭无忘告乃翁",
  "楼船夜雪瓜洲渡铁马秋风大散关",
  "塞上长城空自许镜中衰鬓已先斑",
  "零落成泥碾作尘只有香如故",
  "小楼一夜听春雨深巷明朝卖杏花",
  "位卑未敢忘忧国事定犹须待阖棺",
  "纸上得来终觉浅绝知此事要躬行",
  "文章本天成妙手偶得之"
  ] },
  { name: "家国 · 言志", lines: [
  "人生自古谁无死留取丹心照汗青",
  "山河破碎风飘絮身世浮沉雨打萍",
  "天地有正气杂然赋流形",
  "先天下之忧而忧后天下之乐而乐",
  "不以物喜不以己悲",
  "浊酒一杯家万里燕然未勒归无计",
  "羌管悠悠霜满地人不寐将军白发征夫泪",
  "怒发冲冠凭栏处潇潇雨歇",
  "三十功名尘与土八千里路云和月",
  "莫等闲白了少年头空悲切",
  "壮志饥餐胡虏肉笑谈渴饮匈奴血",
  "待从头收拾旧山河朝天阙",
  "千锤万凿出深山烈火焚烧若等闲",
  "粉骨碎身浑不怕要留清白在人间",
  "咬定青山不放松立根原在破岩中",
  "千磨万击还坚劲任尔东西南北风",
  "衙斋卧听萧萧竹疑是民间疾苦声",
  "些小吾曹州县吏一枝一叶总关情",
  "落红不是无情物化作春泥更护花",
  "九州生气恃风雷万马齐喑究可哀",
  "我劝天公重抖擞不拘一格降人才"
  ] },
  { name: "宋明理趣 · 田园", lines: [
  "春风又绿江南岸明月何时照我还",
  "墙角数枝梅凌寒独自开",
  "遥知不是雪为有暗香来",
  "不畏浮云遮望眼自缘身在最高层",
  "一水护田将绿绕两山排闼送青来",
  "爆竹声中一岁除春风送暖入屠苏",
  "千门万户曈曈日总把新桃换旧符",
  "半亩方塘一鉴开天光云影共徘徊",
  "问渠那得清如许为有源头活水来",
  "等闲识得东风面万紫千红总是春",
  "少年易老学难成一寸光阴不可轻",
  "未觉池塘春草梦阶前梧叶已秋声",
  "小荷才露尖尖角早有蜻蜓立上头",
  "接天莲叶无穷碧映日荷花别样红",
  "毕竟西湖六月中风光不与四时同",
  "正入万山圈子里一山放过一山拦",
  "绿阴不减来时路添得黄鹂四五声",
  "春色满园关不住一枝红杏出墙来",
  "黄梅时节家家雨青草池塘处处蛙",
  "有约不来过夜半闲敲棋子落灯花",
  "绿遍山原白满川子规声里雨如烟",
  "草满池塘水满陂山衔落日浸寒漪",
  "山外青山楼外楼西湖歌舞几时休",
  "暖风熏得游人醉直把杭州作汴州",
  "苔花如米小也学牡丹开",
  "白日不到处青春恰自来",
  "草长莺飞二月天拂堤杨柳醉春烟",
  "儿童散学归来早忙趁东风放纸鸢",
  "采得百花成蜜后为谁辛苦为谁甜",
  "今朝有酒今朝醉明日愁来明日愁",
  "时来天地皆同力运去英雄不自由"
  ] },
  { name: "元曲 · 明清", lines: [
  "枯藤老树昏鸦小桥流水人家古道西风瘦马",
  "夕阳西下断肠人在天涯",
  "伤心秦汉经行处宫阙万间都做了土",
  "兴百姓苦亡百姓苦",
  "少年听雨歌楼上红烛昏罗帐",
  "而今听雨僧庐下鬓已星星也",
  "悲欢离合总无情一任阶前点滴到天明",
  "流光容易把人抛红了樱桃绿了芭蕉",
  "良辰美景奈何天赏心乐事谁家院",
  "则为你如花美眷似水流年",
  "情不知所起一往而深",
  "人生若只如初见何事秋风悲画扇",
  "山一程水一程身向榆关那畔行夜深千帐灯",
  "风一更雪一更聒碎乡心梦不成故园无此声",
  "被酒莫惊春睡重赌书消得泼茶香当时只道是寻常",
  "一生一代一双人争教两处销魂",
  "谁念西风独自凉萧萧黄叶闭疏窗沉思往事立残阳",
  "似此星辰非昨夜为谁风露立中宵",
  "百无一用是书生",
  "满纸荒唐言一把辛酸泪",
  "都云作者痴谁解其中味",
  "假作真时真亦假无为有处有还无",
  "世事洞明皆学问人情练达即文章",
  "好风凭借力送我上青云",
  "花谢花飞花满天红消香断有谁怜",
  "质本洁来还洁去强于污淖陷渠沟",
  "寒塘渡鹤影冷月葬花魂"
  ] },
  { name: "张若虚《春江花月夜》", lines: [
  "春江潮水连海平海上明月共潮生",
  "江天一色无纤尘皎皎空中孤月轮",
  "江畔何人初见月江月何年初照人",
  "人生代代无穷已江月年年望相似",
  "不知江月待何人但见长江送流水",
  "白云一片去悠悠青枫浦上不胜愁",
  "谁家今夜扁舟子何处相思明月楼",
  "玉户帘中卷不去捣衣砧上拂还来",
  "此时相望不相闻愿逐月华流照君",
  "昨夜闲潭梦落花可怜春半不还家",
  "不知乘月几人归落月摇情满江树"
  ] }
];

// 全部诗句（各分组展平，供“全部名句”模式使用）
var poems = [];
for (var gi = 0; gi < poemGroups.length; gi++) {
  poems = poems.concat(poemGroups[gi].lines);
}

// ---- 诗人分组 / 轮播 ----
var currentPool = poems;      // 当前生效的诗句池
var rotateIdx = 0;            // 自动轮播模式下的分组索引
var lastRotate = Date.now();
var ROTATE_MS = 30000;        // 自动轮播每 30 秒切换一组

// 根据面板设置刷新当前诗句池（每帧调用）
function refreshPool() {
  if (root.autoRotate) {
    var now = Date.now();
    if (now - lastRotate >= ROTATE_MS) {
      lastRotate = now;
      rotateIdx = (rotateIdx + 1) % poemGroups.length;
      currentPool = poemGroups[rotateIdx].lines;
      reassignAll();
    } else {
      currentPool = poemGroups[rotateIdx].lines;
    }
  } else if (root.poetGroup >= 1 && root.poetGroup <= poemGroups.length) {
    currentPool = poemGroups[root.poetGroup - 1].lines;
  } else {
    currentPool = poems;
  }
}

function pickPoem() {
  return currentPool[Math.floor(Math.random() * currentPool.length)].split("");
}

// 为每一列重新分配诗句（切换内容 / 分组 / 轮播时调用）
function reassignAll() {
  for (var i = 0; i < colPoem.length; i++) {
    colPoem[i] = pickPoem();
    colIdx[i] = 0;
  }
}

// 原版日文假名字符池（保留，可通过自定义面板切回）
var konkani = "゠アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレワヰヱヲンヺ・ーヽヿ0123456789";
var characters = konkani.split("");

// 汉字字体见文件头 fontPresets（默认楷体），此处不再重复声明

var font_size = 14;
var columns = 0;              // number of columns for the rain

// an array of drops - one per column
var drops = [];
// 整句模式下：每列当前正在下落的诗句，以及已写到第几个字
var colPoem = [];
var colIdx = [];
// 每列上一个已绘制的字符（用于字头高亮时回落重绘）
var lastChar = [];

// 按当前字号重建整个布局（初始化及字号变更时调用）
function buildLayout() {
  columns = Math.floor(viewW / font_size);
  drops = [];
  colPoem = [];
  colIdx = [];
  lastChar = [];
  // 先清屏，避免旧字号的残留字符与新布局错位叠加
  ctx.fillStyle = "rgba(0,0,0,1)";
  ctx.fillRect(0, 0, viewW, viewH);
  for (var x = 0; x < columns; x++) {
    // 让各列错落进入：部分列已在屏内，其余从屏幕上方排队落下
    drops[x] = Math.random() < 0.35
      ? Math.floor(Math.random() * (viewH / font_size))
      : -Math.floor(Math.random() * (viewH / font_size));
    colPoem[x] = pickPoem();
    colIdx[x] = 0;
    lastChar[x] = "";
  }
}
buildLayout();

// ---- 颜色计算 ----
// 全局色相相位：按真实时间推进，因此与下落速度完全解耦。
// 面板上的“彩虹速度”单独调节即可看到明显的快慢变化。
var huePhase = 0;
var lastFrameTime = Date.now();

function baseColor(i) {
  if (root.rainbow) {
    // 叠加列偏移，形成横向流动的彩虹渐变；偏移量由“彩虹渐变跨度”控制
    var p = huePhase + i * root.rainbowSpread;
    return {
      r: Math.floor(127 * Math.sin(p) + 128),
      g: Math.floor(127 * Math.sin(p + 2) + 128),
      b: Math.floor(127 * Math.sin(p + 4) + 128)
    };
  }
  return { r: root.wavecolor.r, g: root.wavecolor.g, b: root.wavecolor.b };
}

// 注意：rgba() 必须写满 4 个分量，否则是非法 CSS 值，Canvas 会静默忽略赋值
function rgba(col, alpha) {
  return 'rgba(' + col.r + ',' + col.g + ',' + col.b + ',' + alpha + ')';
}

// 字头提亮：向白色混合
function brighten(col, k) {
  return {
    r: Math.round(col.r + (255 - col.r) * k),
    g: Math.round(col.g + (255 - col.g) * k),
    b: Math.round(col.b + (255 - col.b) * k)
  };
}

// drawing the characters
function draw() {
    // 自动轮播 / 分组切换在每帧检查
    refreshPool();

    // translucent BG to show trail
    ctx.fillStyle = "rgba(0,0,0," + root.trailAlpha + ")";
    ctx.fillRect(0, 0, viewW, viewH);

    ctx.font = font_size + "px " + fontStack;
    ctx.textBaseline = "top";

    // 色相按真实时间推进：与下落速度无关，单独调“彩虹速度”就能看到明显快慢变化
    // rainbowHz 为每秒循环圈数，一圈 = 2π
    var nowT = Date.now();
    var dt = nowT - lastFrameTime;
    lastFrameTime = nowT;
    if (dt < 0) dt = 0;
    if (dt > 200) dt = 200;   // 后台切回时避免一次性跳变
    huePhase += root.rainbowHz * Math.PI * 2 * (dt / 1000);
    if (huePhase > Math.PI * 2) huePhase -= Math.PI * 2;

    // looping over drops
    for (var i = 0; i < drops.length; i++)
    {
        var x = i * font_size;
        var y = drops[i] * font_size;

        // background color：抹掉字头位置的旧字，避免重影
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(0,0,0,1)";
        ctx.fillRect(x, y, font_size, font_size);

        var text;
        if (root.charMode === 0) {
            // 整句竖排：一列自上而下依次落出完整诗句，写完一句自动接下一句
            if (!colPoem[i] || colIdx[i] >= colPoem[i].length) {
                colPoem[i] = pickPoem();
                colIdx[i] = 0;
            }
            text = colPoem[i][colIdx[i]];
            // 仍在屏幕上方排队时不消耗字符，保证整句从头完整落下
            if (drops[i] >= 0) colIdx[i]++;
        } else if (root.charMode === 1) {
            // 随机单字：从当前诗句池提炼的汉字中随机取字
            var poolStr = currentPool.join("");
            text = poolStr.charAt(Math.floor(Math.random() * poolStr.length));
        } else {
            // 原版：随机日文假名
            text = characters[Math.floor(Math.random() * characters.length)];
        }

        var col = baseColor(i);

        // 字头高亮：上一个字回落为底色，当前字提亮偏白，形成经典的亮头拖尾
        if (root.brightHead) {
            var py = (drops[i] - 1) * font_size;
            if (lastChar[i] && py >= 0) {
                ctx.fillStyle = rgba(col, 1);
                ctx.fillText(lastChar[i], x, py);
            }
            ctx.fillStyle = rgba(brighten(col, 0.6), 1);
        } else {
            ctx.fillStyle = rgba(col, 1);
        }

        if (root.glow > 0) {
            ctx.shadowColor = rgba(col, 0.85);
            ctx.shadowBlur = root.glow;
        }

        ctx.fillText(text, x, y);
        ctx.shadowBlur = 0;
        lastChar[i] = text;

        // Incrementing Y coordinate
        drops[i]++;
        // sending the drop back to the top randomly after it has crossed the screen
        // adding randomness to the reset to make the drops scattered on the Y axis
       if (drops[i] * font_size > viewH && Math.random() > 0.975) {
				      drops[i] = 0;
              lastChar[i] = "";
              colPoem[i] = pickPoem();
              colIdx[i] = 0;
       }
    }
}

window.onresize=()=>{
    location.reload();
}

// 定时器句柄：下落速度变更时重建
var matrixTimer = setInterval(draw, root.matrixspeed);

function setMatrixSpeed(ms) {
  clearInterval(matrixTimer);
  root.matrixspeed = ms;
  matrixTimer = setInterval(draw, ms);
}

// 面板滑杆（0–100）→ 感知型刻度的换算工具。
// 人眼对“快慢”“明暗”的感知是非线性的，线性映射会出现“调了但看不出区别”。
// 这里统一用指数映射拉开尺度，低值细腻微调、高值变化剧烈。

// 彩虹速度：面板 0–100 → 每秒色相循环圈数 0–3 圈（指数曲线）
// 20 档 ≈ 0.03 Hz（缓慢流动），50 档 ≈ 0.35 Hz（明显流转），100 档 = 3 Hz（飞速闪烁）
function rainbowHzFrom(v) {
  if (v <= 0) return 0;
  return 3 * Math.pow(v / 100, 3.2);
}

// 下落速度：面板 0–100 → 每步间隔 160ms–8ms（指数曲线，值越大越快）
function fallDelayFrom(v) {
  var t = Math.max(0, Math.min(100, v)) / 100;
  return Math.round(160 * Math.pow(8 / 160, t));
}

// 拖尾长度：面板 0–100 → 背景遮罩透明度（值越大拖尾越长，即遮罩越淡）
function trailAlphaFrom(v) {
  var t = Math.max(0, Math.min(100, v)) / 100;
  return 0.32 * Math.pow(0.02 / 0.32, t);
}

function livelyPropertyListener(name, val)
{
  switch(name) {
    case "matrixColor":
      root.wavecolor = hexToRgb(val) || root.wavecolor;
      break;
    case "rainBow":
      root.rainbow = !!val;
      break;
    case "rainbowSpeed":
      // 按真实时间推进色相，与下落速度完全解耦；尺度已大幅拉开
      root.rainbowHz = rainbowHzFrom(val);
      break;
    case "rainbowSpread":
      // 列间色相偏移：0 = 全屏几乎同色，100 = 每列错开约 0.6 弧度，横向彩条细密
      root.rainbowSpread = (Math.max(0, Math.min(100, val)) / 100) * 0.6;
      break;
    case "charMode":
      root.charMode = val;
      // 切换文字内容时，为每一列重新分配诗句
      reassignAll();
      lastChar = [];
      for (var a = 0; a < columns; a++) lastChar[a] = "";
      break;
    case "poetGroup":
      // 0 = 全部名句；1..N = 对应分组；N+1 = 自动轮播
      root.poetGroup = val;
      root.autoRotate = val > poemGroups.length;
      if (root.autoRotate) {
        rotateIdx = 0;
        lastRotate = Date.now();
      }
      reassignAll();
      lastChar = [];
      for (var b = 0; b < columns; b++) lastChar[b] = "";
      break;
    case "rotateSec":
      // 自动轮播间隔（秒）
      ROTATE_MS = Math.max(3, val) * 1000;
      lastRotate = Date.now();
      break;
    case "fontSize":
      // 字号：重建整列布局，列宽随之变化
      font_size = Math.max(8, val);
      buildLayout();
      break;
    case "fontPreset":
      fontStack = fontPresets[val] || fontPresets[0];
      root.fontKey = val;
      break;
    case "fallSpeed":
      setMatrixSpeed(fallDelayFrom(val));
      break;
    case "trail":
      // 0 = 几乎无拖尾，100 = 极长拖尾
      root.trailAlpha = trailAlphaFrom(val);
      break;
    case "glow":
      // 发光强度：0 = 关闭，最大 24px 模糊半径
      root.glow = Math.max(0, Math.min(24, val));
      break;
    case "brightHead":
      root.brightHead = !!val;
      break;
    case "hidpi":
      root.hidpi = !!val;
      setupCanvas();
      buildLayout();
      break;
  }
}

function hexToRgb(hex) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}
